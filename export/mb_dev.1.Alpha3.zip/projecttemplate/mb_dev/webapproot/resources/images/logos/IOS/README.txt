Web Applications (using iPhone's Add to HomePage command from the web application).
Configure this in your login.html and index.html files.
64x64:   iPhone Icon via apple-touch-icon-precomposed 
240x360: iPhone Splash Screen via apple-touch-startup-image 

ICONS
57x57:   iPhone Icon
72x72:   iPhone Retina Icon
114x114: iPad Icon
144x144: iPad Retina Icon
  

SPLASH SCREENS
320x480:   iPhone Portrait Splash Screen
640x960:   iPhone Retina Splash Screen
1024x748:  iPad Landscape Splash Screen
768x1004:  iPad Portrait Splash Screen
1536x2008: iPad Retina Portrait Splash Screen
2048x1496: iPad Retina Landscape Splash Screen
