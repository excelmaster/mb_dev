
package com.invent_mbdb.data;



/**
 *  invent_mbDB.AdminRedir
 *  06/16/2014 12:03:46
 * 
 */
public class AdminRedir {

    private Integer id;
    private Integer grupo;
    private String nameSitio;
    private String linkSitio;
    private String imgSitio;
    private String page;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getGrupo() {
        return grupo;
    }

    public void setGrupo(Integer grupo) {
        this.grupo = grupo;
    }

    public String getNameSitio() {
        return nameSitio;
    }

    public void setNameSitio(String nameSitio) {
        this.nameSitio = nameSitio;
    }

    public String getLinkSitio() {
        return linkSitio;
    }

    public void setLinkSitio(String linkSitio) {
        this.linkSitio = linkSitio;
    }

    public String getImgSitio() {
        return imgSitio;
    }

    public void setImgSitio(String imgSitio) {
        this.imgSitio = imgSitio;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }

}
