
package com.invent_mbdb;



/**
 *  Query names for service "invent_mbDB"
 *  06/16/2014 12:50:58
 * 
 */
public class Invent_mbDBConstants {

    public final static String getUsersByIdQueryName = "getUsersById";

}
